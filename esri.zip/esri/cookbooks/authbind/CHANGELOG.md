## v0.1.10:

* Fix     : Correctly handle ports >= 512. Submitted by Marius Sturm.

## v0.1.8:

* Change  : Remove outdated cutlery depends from cookbook metadata.

## v0.1.6:

* Change  : Replace the use of cutlery dependency with Chef 11's use_inline_resources method.

## v0.1.4:

* Change  : Use default_action method in resource DSL to mark default actions.
* Enhance : Add dependency on cutlery to reuse notifying_action so LWRPs correctly notify.

## v0.1.3:

* Enhance : Add authbind_addr resource. (Imported from John Whitley's work at https://github.com/jwhitley/authbind).

## v0.1.2:

* Enhance : Support configuration of group for port resource. (Inspired by Zuhaib Siddique's work at https://github.com/zsiddique/authbind).

## v0.1.1:

* Enhance : Minor documentation improvements.

## v0.1.0:

* Initial release
