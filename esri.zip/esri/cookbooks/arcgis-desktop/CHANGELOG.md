arcgis-desktop cookbook CHANGELOG
=================================

This file is used to list changes made in each version of the arcgis-desktop cookbook.

3.2.0
-----
- Added support for ArcGIS 10.6.

3.1.0
-----
- Added support for ArcGIS 10.5.1.

3.0.0
-----
- Updated ArcGIS product names

2.3.1
-----
- Added support for ArcGIS 10.5.

2.3.0
-----
- Added support for ArcGIS 10.5 Beta.
- Split from arcgis 2.2.1 cookbook.

