# for system limits.conf
default['limits']['system_conf'] = '/etc/security/limits.conf'

# for limits.d
default['limits']['conf_dir'] = '/etc/security/limits.d'
