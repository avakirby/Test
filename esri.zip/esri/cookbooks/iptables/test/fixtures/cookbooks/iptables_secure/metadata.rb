name 'iptables_secure'
version '0.0.1'

depends 'iptables'
