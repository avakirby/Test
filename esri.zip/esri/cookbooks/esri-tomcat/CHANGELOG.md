esri-tomcat cookbook CHANGELOG
================================

This file is used to list changes made in each version of the esri-tomcat cookbook.

0.1.2
-----
- Update tomcat dependency version > 2.5.2
- Fix chef 14 deprecation warnings
- Update kitchen to use chef 13

0.1.1
-----
- Add additional guard for tomcat_install resource
- Fix some rubocop offenses

0.1.0
-----
- Installs and configures Apache Tomcat for using with ArcGIS Web Adaptor
