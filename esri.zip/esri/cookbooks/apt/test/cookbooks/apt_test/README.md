This cookbook is used with test-kitchen to test the parent, apt cookbok
