# arcgis-insights CHANGELOG

This file is used to list changes made in each version of the arcgis-insights cookbook.

## 3.2.0
- Added support for Insights for ArcGIS 2.0/2.1

## 3.1.0
- Added support for Insights for ArcGIS 1.2

## 3.0.0
- Initial release of arcgis-insights cookbook
