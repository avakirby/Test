require File.expand_path('../support/helpers', __FILE__)

describe 'line::default' do
  include Helpers::Line

  # Example spec tests can be found at http://git.io/Fahwsw
  it 'runs no tests by default' do
  end
end
