#
# Cookbook:: test_java
# Recipe:: default
#
# Copyright:: 2014
#
# All rights reserved - Do Not Redistribute
#

cookbook_file '/tmp/UnlimitedSupportJCETest.jar' do
  source 'UnlimitedSupportJCETest.jar'
end
