# mt-server Cookbook

This cookbook installs and configures ArcGIS Online MT Server.

## Requirements

TODO: List your cookbook requirements. Be sure to include any requirements this cookbook has on platforms, libraries, other cookbooks, packages, operating systems, etc.

### Platforms

- Windows

### Chef

- Chef 12.0 or later

### Cookbooks

- windows
- openssl
- java_properties
- arcgis-enterprise

## Attributes

- `node['java']['setup']` - JRE setup path. Default `\\warlockdeploy1\DepFiles\JRE\8u121\jre-8u121-windows-x64.exe`.
- `node['java']['java_home']` - JAVA_HOME path. Default `%ProgramW6432%\Java\jre1.8.0_121`.

- `node['tomcat']['version']` - Tomcat version. Default `7.0.73`.
- `node['tomcat']['setup']` - Tomcat setup path, Default `\\warlockdeploy1\DepFiles\Tomcat\7.0.73\apache-tomcat-7.0.73-windows-x64.zip`.
- `node['tomcat']['install_dir']` - Tomcat installation directory. Default `%ProgramW6432%\Apache Software Foundation`.
- `node['tomcat']['install_subdir']` - Tomcat installation sub-directory. Default `apache-tomcat-7.0.73`.
- `node['tomcat']['catalina_home']` - CATALINA_HOME directory. Default `%ProgramW6432%\Apache Software Foundation\apache-tomcat-7.0.73`.
- `node['tomcat']['ssl_enabled_protocols']` - SSL protocols enabled on Tomcat. Default `TLSv1.2,TLSv1.1,TLSv1`.
- `node['tomcat']['keystore_file']` - Tomcat keystore file path. Default ``.
- `node['tomcat']['keystore_password']` - Keystore file password. Default ``.
- `node['tomcat']['keystore_type']` - Keystore type. Default `PKCS12`
- `node['tomcat']['domain_name']` SSL certificate domain name. Default `FQDN of the machine`.

- `node['arcgis']['mt_server']['profile']` - MT Server deployment profile. Default `analysis-azure`.
- `node['arcgis']['mt_server']['package_url']` - MT Server build package URL. Default `https://builds-2.arcgis.com/job/builds-mt-server/lastStableBuild/com.esri.arcgis.server$mt-server/artifact/com.esri.arcgis.server/mt-server/3.3/mt-server-3.3-analysis-azure.zip`
- `node['arcgis']['mts_admin_tools']['package_url']` - MT Server Admin Tools build package URL. Default `https://builds-2.arcgis.com/job/builds-mt-server/lastStableBuild/com.esri.arcgis.server$mts-admin-tools/artifact/com.esri.arcgis.server/mts-admin-tools/3.3-SNAPSHOT/mts-admin-tools-3.3-SNAPSHOT-windows.zip`
- `node['arcgis']['mts_admin_tools']['install_dir']` - MT Server Admin Tools installation directory. Default `C:\mts`
- `node['arcgis']['mts_admin_tools']['install_subdir']` - MT Server Admin Tools installation sub-directory. Default `mts-admin-tools-3.3-SNAPSHOT`
- `node['arcgis']['mts_admin_tools']['home']` - MT Server Admin Tools home directory. Default  = `C:\mts\mts-admin-tools-3.3-SNAPSHOT`
- `node['arcgis']['mt_server']['server_directories_root']` - Path to directory that will be used to store server directories. Default `C:\\\\arcgisserver`.
- `node['arcgis']['mt_server']['cluster']` - Name of the server cluster. Default `analysis1`
- `node['arcgis']['mt_server']['azure_storage_connection_ctring']` - Cluster store connection string. Default `DefaultEndpointsProtocol=https;AccountName=<your storage account name>;AccountKey=<your storage account key>`
- `node['arcgis']['mt_server']['deployment_type']` - Type of the server cluster deployment. Default `analysis`
- `node['arcgis']['mt_server']['deployment_id']` - ID of the server cluster deployment. Default `deployment1`.
- `node['arcgis']['mt_server']['host_id']` - ID of he host machine, such as VM instance name. Default `VM_1`.
- `node['arcgis']['mt_server']['[portal_issued_secret_key']` Secret key issued to the server by portal. Default `ZZZ`
- `node['arcgis']['mt_server']['server_url']` - URL of a federated server for which a server-token needs to be generated. Default `http://analysisdev.arcgis.com`
- `node['arcgis']['mt_server']['primary_admin_username']` - Username of the primary server administrator. Default `admin`
- `node['arcgis']['mt_server']['primary_admin_password']` - Password of the primary server administrator. Default `pa$$w0rd`.
- `node['arcgis']['mt_server']['read_only_admin_username']` - Username of the read-only server administrator. Default ``.
- `node['arcgis']['mt_server']['read_only_admin_password']` - Password of the read-only server administrator. Default ``.
- `node['arcgis']['mt_server']['token_shared_key']` - Secret key used to encrypt primary server administrator's tokens issued by the server. Default `changeit`.
- `node['arcgis']['mt_server']['signature_key']` - Default key used to validate signatures of requests to the server. Default `XXX`.
- `node['arcgis']['mt_server']['signature_keys']` - Key map used to validate signatures of requests to the server. Default `as XXX`
- `node['arcgis']['mt_server']['owning_system_url']` - Portal URL. Default `https://devext.arcgis.com`.
- `node['arcgis']['mt_server']['token_service_url']` - Token service URL. Default `https://devext.arcgis.com/sharing/rest/generateToken`
- `node['arcgis']['mt_server']['services_html_ui_enabled']` - If set to false, disables HTML UI (aka services directory) on /rest webapp. Default `true`.
- `node['arcgis']['mt_server']['layer_admin_key']` - Property used by GP services framework. Default `testing`.
- `node['arcgis']['mt_server']['cost_calculator']` - Property used by GP services framework. Default `EstimateSOE`.
- `node['arcgis']['mt_server']['esri_hosted_layers_path']` - Property used by GP services framework. Default `C:\EsriHostedLayers`.
- `node['arcgis']['mt_server']['esri_hosted_layers_org_id']` - Property used by GP services framework. Default `XXX`.
- `node['arcgis']['mt_server']['is_online']` - Property used by GP services framework. Default `true`.
- `node['arcgis']['mt_server']['filter_gp_messages']` - If GP message filtering is set to true, only errors and warnings are returned for GP jobs in GP service job info. Default `false`.
- `node['arcgis']['mt_server']['usage_metering_enabled']` - If set to true usage metering is enabled in ArcGIS Server. Default `false`.
- `node['arcgis']['mt_server']['asm_url']` - Keys used to configure usage metering plugin in ArcGIS Server's NodeEgentExt.xml file. Default `https://asmdevext.arcgis.com/admin`.
- `node['arcgis']['mt_server']['asm_access_key']` - ASM access key. Default `gw`.
- `node['arcgis']['mt_server']['asm_signature_keys']` ASM signature keys. Default, `gw ZZZ`
- `node['arcgis']['mt_server']['userDataItem']` - Tenant databases data item path. Default `/enterpriseDatabases/${user.accountId}/db`


## Recipes

- `default` - Deploys and configures MT Server's web applications.
- `admin_tools` - Installs MT Server Admin Tools.
- `arcgis_server` - Installs and authorizes ArcGIS Server.
- `cluster-store` - Creates cluster store in the Azure storage account.
- `java` - Installs JRE.
- `tomcat` - Installs Apache Tomcat.



