#
# Cookbook Name:: mt-server
# Attributes:: default
#
# Copyright 2017 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

default['java']['setup'] = '\\\\warlockdeploy1\\DepFiles\\JRE\\8u121\\jre-8u121-windows-x64.exe'
default['java']['java_home'] = ::File.join(ENV['ProgramW6432'], 'Java', 'jre1.8.0_121')

default['tomcat']['version'] = '7.0.73'
default['tomcat']['setup'] = "\\\\warlockdeploy1\\DepFiles\\Tomcat\\#{node['tomcat']['version']}\\apache-tomcat-#{node['tomcat']['version']}-windows-x64.zip"
default['tomcat']['install_dir'] = ::File.join(ENV['ProgramW6432'], 'Apache Software Foundation')
default['tomcat']['install_subdir'] = "apache-tomcat-#{node['tomcat']['version']}"
default['tomcat']['catalina_home'] = ::File.join(node['tomcat']['install_dir'], node['tomcat']['install_subdir'])

default['tomcat']['ssl_enabled_protocols'] = 'TLSv1.2,TLSv1.1,TLSv1'
default['tomcat']['keystore_file']  = ''
if ENV['TOMCAT_KEYSTORE_PASSWORD'].nil?
  default['tomcat']['keystore_password']  = ''
else
  default['tomcat']['keystore_password']  = ENV['TOMCAT_KEYSTORE_PASSWORD']
end
default['tomcat']['keystore_type']  = 'PKCS12'
default['tomcat']['domain_name']  = node['fqdn']

default['arcgis']['mt_server']['profile'] = 'analysis-azure'
default['arcgis']['mt_server']['package_url'] = "https://builds-2.arcgis.com/job/builds-mt-server/lastStableBuild/com.esri.arcgis.server$mt-server/artifact/com.esri.arcgis.server/mt-server/3.3/mt-server-3.3-#{node['arcgis']['mt_server']['profile']}.zip"
default['arcgis']['mts_admin_tools']['package_url'] = 'https://builds-2.arcgis.com/job/builds-mt-server/lastStableBuild/com.esri.arcgis.server$mts-admin-tools/artifact/com.esri.arcgis.server/mts-admin-tools/3.3-SNAPSHOT/mts-admin-tools-3.3-SNAPSHOT-windows.zip'
default['arcgis']['mts_admin_tools']['install_dir'] = 'C:\\mts'
default['arcgis']['mts_admin_tools']['install_subdir'] = 'mts-admin-tools-3.3-SNAPSHOT'
default['arcgis']['mts_admin_tools']['home'] = ::File.join(node['arcgis']['mts_admin_tools']['install_dir'],
                                                      node['arcgis']['mts_admin_tools']['install_subdir'])

#Path to directory that will be used to store server directories
default['arcgis']['mt_server']['server_directories_root'] = 'C:\\\\arcgisserver'

#Name of the server cluster created using 'azure-store create-store' tool
default['arcgis']['mt_server']['cluster'] = 'analysis1'

#Cluster store connection string 
default['arcgis']['mt_server']['azure_storage_connection_ctring'] = 'DefaultEndpointsProtocol=https;AccountName=<your storage account name>;AccountKey=<your storage account key>'

#Type of the server cluster deployment 
default['arcgis']['mt_server']['deployment_type'] = 'analysis'

#ID of the server cluster deployment 
default['arcgis']['mt_server']['deployment_id'] = 'deployment1'

#ID of he host machine, such as VM instance name
default['arcgis']['mt_server']['host_id'] = 'VM_1'

#Secret key issued to the server by portla
default['arcgis']['mt_server']['[portal_issued_secret_key'] = 'ZZZ'

#URL of a federated server for which a server-token needs to be generated. 
default['arcgis']['mt_server']['server_url'] = 'http://analysisdev.arcgis.com'

#Username of the primary server administrator 
default['arcgis']['mt_server']['primary_admin_username'] = 'admin'

#Password of the primary server administrator
default['arcgis']['mt_server']['primary_admin_password'] = 'pa$$w0rd'

#Username of the read-only server administrator 
default['arcgis']['mt_server']['read_only_admin_username'] = ''

#Password of the read-only server administrator
default['arcgis']['mt_server']['read_only_admin_password'] = ''

#Secret key used to encrypt primary server administrator's tokens issued by the server 
default['arcgis']['mt_server']['token_shared_key'] = 'changeit'

#Default key used to validate signatures of requests to the server
default['arcgis']['mt_server']['signature_key'] = 'XXX'

#Key map used to validate signatures of requests to the server
#SignatureKeys=accesskey1 secretkey1;accesskey2 secretkey2
default['arcgis']['mt_server']['signature_keys'] = 'as XXX'

#Portal URL
default['arcgis']['mt_server']['owning_system_url'] = 'https://devext.arcgis.com'

#Token service URL 
default['arcgis']['mt_server']['token_service_url'] = node['arcgis']['mt_server']['owning_system_url'] + '/sharing/rest/generateToken'

#If set to false, disables HTML UI (aka services directory) on /rest webapp.   
default['arcgis']['mt_server']['services_html_ui_enabled'] = true

#Properties used by GP services framework
default['arcgis']['mt_server']['layer_admin_key'] = 'testing'
default['arcgis']['mt_server']['cost_calculator'] = 'EstimateSOE'
default['arcgis']['mt_server']['esri_hosted_layers_path'] = 'C:\\\\EsriHostedLayers'
default['arcgis']['mt_server']['esri_hosted_layers_org_id'] = 'XXX'
default['arcgis']['mt_server']['is_online'] = true

#If GP message filtering is set to true, only errors and warnings are 
#returned for GP jobs in GP service job info.  
default['arcgis']['mt_server']['filter_gp_messages'] = false

#If set to true usage metering is enabled in ArcGIS Server
default['arcgis']['mt_server']['usage_metering_enabled'] = false

#Keys used to configure usage metering plugin in ArcGIS Server's NodeEgentExt.xml file  
default['arcgis']['mt_server']['asm_url']= 'https://asmdevext.arcgis.com/admin'
default['arcgis']['mt_server']['asm_access_key'] = 'gw'
default['arcgis']['mt_server']['asm_signature_keys'] = 'gw YYY'

default['arcgis']['mt_server']['userDataItem'] = '/enterpriseDatabases/${user.accountId}/db'

default['arcgis']['mts_admin_tools']['cluster_connection_file'] = ::File.join(node['arcgis']['mts_admin_tools']['install_dir'], node['arcgis']['mt_server']['cluster'] + '-connection.properties')
default['arcgis']['mt_server']['admin_url'] = "https://#{node['fqdn']}:8443/arcgis/admin"