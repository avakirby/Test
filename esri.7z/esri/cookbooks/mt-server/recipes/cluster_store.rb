#
# Cookbook Name:: mt-server
# Recipe:: cluster_store
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#

java_properties node['arcgis']['mts_admin_tools']['cluster_connection_file'] do
  Cluster node['arcgis']['mt_server']['cluster']
  AzureStorageConnectionString node['arcgis']['mt_server']['azure_storage_connection_ctring']
  AdminURL node['arcgis']['mt_server']['admin_url']
  Username node['arcgis']['mt_server']['primary_admin_username']
  Password node['arcgis']['mt_server']['primary_admin_password']
end

create_store_command = ::File.join(node['arcgis']['mts_admin_tools']['home'], 'bin\\azure-admin.bat') +
                                     ' create-store -C ' +
                                     node['arcgis']['mts_admin_tools']['cluster_connection_file']

describe_store_command = ::File.join(node['arcgis']['mts_admin_tools']['home'], 'bin\\azure-admin.bat') + 
                                     ' describe-store -C ' +
                                     node['arcgis']['mts_admin_tools']['cluster_connection_file']

env = { 'JAVA_HOME' => node['java']['java_home'], 'AGS_ADMIN_CLI_HOME' => node['arcgis']['mts_admin_tools']['home']}

execute 'Create cluster store' do
  command create_store_command
  environment env
  only_if do
    cmd = Mixlib::ShellOut.new(describe_store_command,  { :environment => env })
    cmd.run_command
    cmd.error?
  end
end
