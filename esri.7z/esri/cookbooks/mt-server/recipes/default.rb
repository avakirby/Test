#
# Cookbook Name:: mt-server
# Recipe:: default
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#

windows_zipfile node['tomcat']['catalina_home'] do
  source node['arcgis']['mt_server']['package_url']
  overwrite true
  action :unzip
end

template ::File.join(node['tomcat']['catalina_home'], 'shared/host-config.properties') do
  source 'host-config.properties.erb'
end

template ::File.join(node['tomcat']['catalina_home'], 'shared/server-config.properties') do
  source 'server-config.properties.erb'
end

service 'Tomcat7' do
  action :start
end