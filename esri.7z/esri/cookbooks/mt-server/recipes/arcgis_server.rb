#
# Cookbook Name:: mt-server
# Recipe:: arcgis_server
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#

arcgis_enterprise_server "Install System Requirements:#{recipe_name}" do
  action :system
  only_if { node['arcgis']['server']['install_system_requirements'] }
end

arcgis_enterprise_server 'Setup ArcGIS Server' do
  setup node['arcgis']['server']['setup']
  install_dir node['arcgis']['server']['install_dir']
  python_dir node['arcgis']['python']['install_dir']
  run_as_user node['arcgis']['run_as_user']
  run_as_password node['arcgis']['run_as_password']
  not_if { Utils.product_installed?(node['arcgis']['server']['product_code']) }
  action :install
end

arcgis_enterprise_server 'Authorize ArcGIS Server' do
  authorization_file node['arcgis']['server']['authorization_file']
  authorization_file_version node['arcgis']['server']['authorization_file_version']
  not_if { ::File.exists?(node['arcgis']['server']['cached_authorization_file']) &&
           FileUtils.compare_file(node['arcgis']['server']['authorization_file'],
                                  node['arcgis']['server']['cached_authorization_file']) }
  action :authorize
end
