#
# Cookbook Name:: mt-server
# Recipe:: admin_tools
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#

directory node['arcgis']['mts_admin_tools']['install_dir'] do
  recursive true
  action :create
end

windows_zipfile node['arcgis']['mts_admin_tools']['install_dir'] do
  source node['arcgis']['mts_admin_tools']['package_url']
  overwrite true
  action :unzip
end

env 'AGS_ADMIN_CLI_HOME' do
  value node['arcgis']['mts_admin_tools']['home']
end

env 'Path' do
  value ENV['Path'] + ';%AGS_ADMIN_CLI_HOME%\\bin'
end
