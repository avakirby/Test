#
# Cookbook Name:: mt-server
# Recipe:: tomcat
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#
require 'openssl'

directory node['tomcat']['install_dir'] do
  recursive true
  action :create
end

windows_zipfile node['tomcat']['install_dir'] do
  source node['tomcat']['setup']
  not_if {::File.exists?(::File.join(node['tomcat']['catalina_home'], 'LICENSE'))}
  action :unzip
end

keystore_file = node['tomcat']['keystore_file']
keystore_password = node['tomcat']['keystore_password']
certs_dir = ::File.join(node['tomcat']['catalina_home'], 'certificates')

# Generate Self Signed if no keystore is provided
if keystore_file.empty? && keystore_password.empty?
  directory certs_dir do
    action :create
  end

  keystore_file = node.set['tomcat']['keystore_file'] = ::File.join(certs_dir, node['tomcat']['domain_name']) + '.pfx'
  keystore_password = node.set['tomcat']['keystore_password'] = 'changeit'

  openssl_x509 keystore_file.gsub(/\.pfx/, '.pem') do
    common_name node['tomcat']['domain_name']
    org 'test'
    org_unit 'dev'
    country 'US'
    expire 365
    only_if { !::File.exist?(keystore_file) }
    notifies :run, 'ruby_block[Convert to PKCS12]', :immediately
  end

  ruby_block 'Convert to PKCS12' do
    block do
      pfx_file = keystore_file
      keystore_pass = keystore_password
      cert_file = pfx_file.gsub(/\.pfx/, '.pem')
      key_file = pfx_file.gsub(/\.pfx/, '.key')

      # Convert certificate to PKCS12
      key = OpenSSL::PKey.read(::File.read(key_file))
      cert = OpenSSL::X509::Certificate.new(::File.read(cert_file))
      pkcs12 = OpenSSL::PKCS12.create(keystore_pass, nil, key, cert)

      ::File.open(pfx_file, 'wb') do |output|
        output.write(pkcs12.to_der)
      end
    end
    action :nothing
  end
# Warn for providing keystore w/o password
elsif !keystore_file.empty? && keystore_password.empty?
  Chef::Log.warn("node['tomcat']['keystore_password'] is empty! SSL will not be configured!")
end

template ::File.join(node['tomcat']['catalina_home'], 'conf/server.xml') do
  source 'server.xml.erb'
  variables ({ :ssl_enabled_protocols => node['tomcat']['ssl_enabled_protocols'], 
               :keystore_file => keystore_file, 
               :keystore_password => keystore_password,
               :keystore_type => node['tomcat']['keystore_type']})
end

execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //DS//Tomcat7" do
  ignore_failure true
end

execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //IS//Tomcat7 --DisplayName \"Apache Tomcat 7\" --Description \"Apache Tomcat 7\" --LogPath \"#{node['tomcat']['catalina_home']}\\logs\" --Install \"#{node['tomcat']['catalina_home']}\\bin\\Tomcat7.exe\" --Jvm \"#{node['java']['java_home']}\\bin\\server\\jvm.dll\" --StartPath \"#{node['tomcat']['catalina_home']}\" --StopPath \"#{node['tomcat']['catalina_home']}\"" 
execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //US//Tomcat7 --Startup auto\""
execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //US//Tomcat7 --Classpath \"#{node['tomcat']['catalina_home']}\\bin\\bootstrap.jar;#{node['tomcat']['catalina_home']}\\bin\\tomcat-juli.jar\" --StartClass org.apache.catalina.startup.Bootstrap --StopClass org.apache.catalina.startup.Bootstrap --StartParams start --StopParams stop  --StartMode jvm --StopMode jvm"
execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //US//Tomcat7 --JvmOptions \"-Dcatalina.home=#{node['tomcat']['catalina_home']}#-Dcatalina.base=#{node['tomcat']['catalina_home']}#-Djava.endorsed.dirs=#{node['tomcat']['catalina_home']}\\endorsed#-Djava.io.tmpdir=#{node['tomcat']['catalina_home']}\\temp#-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager#-Djava.util.logging.config.file=#{node['tomcat']['catalina_home']}\\conf\\logging.properties\"" 
execute "\"#{node['tomcat']['catalina_home']}\\bin\\tomcat7.exe\" //US//Tomcat7 --StdOutput auto --StdError auto"
