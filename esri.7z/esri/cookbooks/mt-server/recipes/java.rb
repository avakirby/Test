#
# Cookbook Name:: mt-server
# Recipe:: java
#
# Copyright 2017, Esri
#
# All rights reserved - Do Not Redistribute
#

execute 'Install JRE' do
  command "\"#{node['java']['setup']}\" /s"
  not_if {::File.exists?(::File.join(node['java']['java_home'], "LICENSE"))}
end

env 'JAVA_HOME' do
  value node['java']['java_home']
end

