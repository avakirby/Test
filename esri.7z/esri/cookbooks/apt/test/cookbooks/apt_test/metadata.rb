name              'apt_test'
maintainer        'Chef Software, Inc.'
maintainer_email  'cookbooks@chef.io'
license           'Apache 2.0'
description       'This cookbook is used with test-kitchen to test the parent, apt cookbok'
version           '1.0.0'
depends "apt"
