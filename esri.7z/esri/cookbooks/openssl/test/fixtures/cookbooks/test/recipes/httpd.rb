service('httpd') { action :nothing }
