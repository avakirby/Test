if /cygwin|mswin|mingw|bccwin|wince|emx/ =~ RUBY_PLATFORM
  cookbook_path ['C:\\chef\\cookbooks']
else
  cookbook_path ['/var/chef/cookbooks']
end